
StockAppAndroid_v2 - Plantilla básica

Características incluidas:
- Agregar materiales con nombre, categoría, proveedor, precio, stock y stock mínimo.
- Alerta visual "BAJO STOCK" en la lista cuando stock <= stock mínimo.
- Exportar a CSV (archivo: Downloads/stock_export.csv).
- Backup JSON (archivo: Downloads/stock_backup.json) y restauración desde ese backup.
- Login simple con PIN (default: 1234). Cambiar PIN en el código si querés.

Instrucciones rápidas:
1) Descomprimir el ZIP.
2) Abrir el proyecto en Android Studio (en PC).
3) Compilar y correr en un dispositivo Android (o generar APK e instalar en el celular).
4) En la primera pantalla ingresar PIN 1234 y luego usar la app.

Limitaciones:
- No incluye escaneo de códigos QR ni sincronización en la nube (Google Drive) en esta plantilla.
- Para sincronización en la nube habrá que integrar servicios y credenciales (puedo hacerlo después).

Si querés que yo genere el APK listo para instalar en tu teléfono (archivo .apk), decímelo y te lo doy.
