
package com.example.stockapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Toast;
import com.example.stockapp.databinding.ActivityMainBinding;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.BufferedReader;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ActivityMainBinding binding;
    ArrayList<Product> products = new ArrayList<>();
    String PIN = "1234"; // default PIN, can be changed in settings

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Request storage permissions for export/backup
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }

        binding.btnLogin.setOnClickListener(v -> {
            String pin = binding.txtPin.getText().toString();
            if(pin.equals(PIN)){
                binding.loginLayout.setVisibility(View.GONE);
                binding.appLayout.setVisibility(View.VISIBLE);
                loadProductsFromFile();
                refreshList();
            } else {
                Toast.makeText(this, "PIN incorrecto", Toast.LENGTH_SHORT).show();
            }
        });

        binding.btnAdd.setOnClickListener(v -> {
            String name = binding.txtName.getText().toString();
            String category = binding.txtCat.getText().toString();
            String provider = binding.txtProvider.getText().toString();
            int stock = Integer.parseInt(binding.txtStock.getText().toString());
            int minStock = Integer.parseInt(binding.txtMinStock.getText().toString());
            double price = Double.parseDouble(binding.txtPrice.getText().toString());
            Product p = new Product(name, category, provider, price, stock, minStock);
            products.add(p);
            saveProductsToFile();
            refreshList();
        });

        binding.btnExportCsv.setOnClickListener(v -> {
            try {
                exportCsv();
                Toast.makeText(this, "Exportado CSV a Descargas", Toast.LENGTH_LONG).show();
            } catch (Exception e){
                Toast.makeText(this, "Error exportando: "+e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

        binding.btnBackup.setOnClickListener(v -> {
            try {
                backupJson();
                Toast.makeText(this, "Backup creado en Descargas", Toast.LENGTH_LONG).show();
            } catch (Exception e){
                Toast.makeText(this, "Error backup: "+e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

        binding.btnRestore.setOnClickListener(v -> {
            try {
                restoreJson();
                refreshList();
                Toast.makeText(this, "Restore completado", Toast.LENGTH_LONG).show();
            } catch (Exception e){
                Toast.makeText(this, "Error restore: "+e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

    }

    void refreshList(){
        StringBuilder sb = new StringBuilder();
        sb.append("Nombre | Categoria | Proveedor | Precio | Stock | Min
");
        for(Product p: products){
            sb.append(p.name).append(" | ").append(p.category).append(" | ").append(p.provider)
              .append(" | ").append(p.price).append(" | ").append(p.stock).append(" | ").append(p.minStock);
            if(p.stock <= p.minStock){
                sb.append("  <<< BAJO STOCK");
            }
            sb.append("\n");
        }
        binding.txtList.setText(sb.toString());
    }

    void exportCsv() throws Exception {
        File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        File f = new File(dir, "stock_export.csv");
        FileWriter fw = new FileWriter(f);
        fw.write("Nombre, Categoria, Proveedor, Precio, Stock, MinStock\n");
        for(Product p: products){
            fw.write(String.format("%s,%s,%s,%.2f,%d,%d\n", p.name, p.category, p.provider, p.price, p.stock, p.minStock));
        }
        fw.close();
    }

    void backupJson() throws Exception {
        File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        File f = new File(dir, "stock_backup.json");
        JSONArray arr = new JSONArray();
        for(Product p: products){
            JSONObject o = new JSONObject();
            o.put("name", p.name);
            o.put("category", p.category);
            o.put("provider", p.provider);
            o.put("price", p.price);
            o.put("stock", p.stock);
            o.put("minStock", p.minStock);
            arr.put(o);
        }
        FileWriter fw = new FileWriter(f);
        fw.write(arr.toString(2));
        fw.close();
    }

    void restoreJson() throws Exception {
        File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        File f = new File(dir, "stock_backup.json");
        if(!f.exists()) throw new Exception("No se encontró stock_backup.json en Descargas");
        BufferedReader br = new BufferedReader(new FileReader(f));
        StringBuilder sb = new StringBuilder();
        String line;
        while((line=br.readLine())!=null) sb.append(line);
        br.close();
        JSONArray arr = new JSONArray(sb.toString());
        products.clear();
        for(int i=0;i<arr.length();i++){
            JSONObject o = arr.getJSONObject(i);
            Product p = new Product(o.getString("name"), o.getString("category"), o.getString("provider"),
                    o.getDouble("price"), o.getInt("stock"), o.getInt("minStock"));
            products.add(p);
        }
        saveProductsToFile();
    }

    void saveProductsToFile(){
        try {
            File f = new File(getFilesDir(), "products.json");
            JSONArray arr = new JSONArray();
            for(Product p: products){
                JSONObject o = new JSONObject();
                o.put("name", p.name);
                o.put("category", p.category);
                o.put("provider", p.provider);
                o.put("price", p.price);
                o.put("stock", p.stock);
                o.put("minStock", p.minStock);
                arr.put(o);
            }
            FileWriter fw = new FileWriter(f);
            fw.write(arr.toString(2));
            fw.close();
        } catch (Exception e){}
    }

    void loadProductsFromFile(){
        try {
            File f = new File(getFilesDir(), "products.json");
            if(!f.exists()) return;
            BufferedReader br = new BufferedReader(new FileReader(f));
            StringBuilder sb = new StringBuilder();
            String line;
            while((line=br.readLine())!=null) sb.append(line);
            br.close();
            JSONArray arr = new JSONArray(sb.toString());
            products.clear();
            for(int i=0;i<arr.length();i++){
                JSONObject o = arr.getJSONObject(i);
                Product p = new Product(o.getString("name"), o.getString("category"), o.getString("provider"),
                        o.getDouble("price"), o.getInt("stock"), o.getInt("minStock"));
                products.add(p);
            }
        } catch (Exception e){}
    }
}
