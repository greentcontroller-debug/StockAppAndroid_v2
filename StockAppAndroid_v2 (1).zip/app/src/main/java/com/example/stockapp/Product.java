
package com.example.stockapp;

public class Product {
    public String name;
    public String category;
    public String provider;
    public double price;
    public int stock;
    public int minStock;

    public Product(String name, String category, String provider, double price, int stock, int minStock){
        this.name = name;
        this.category = category;
        this.provider = provider;
        this.price = price;
        this.stock = stock;
        this.minStock = minStock;
    }
}
